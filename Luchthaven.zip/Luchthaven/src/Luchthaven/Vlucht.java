package Luchthaven;

import Luchthaven.People.Passagier;
import Luchthaven.People.Personeel.Bagagist;
import Luchthaven.People.Personeel.Personeel;
import Luchthaven.People.Personeel.Piloot;
import Luchthaven.People.Personeel.Steward;

import java.util.ArrayList;
import java.util.List;

public class Vlucht {
private String vluchtCode;
private String bestemming;

//lijsten passagiers + personeel + Tickets;

private List<Passagier> passagiers;
private List<Personeel> personeel;
private List<Tickets> tickets;


private int economySeats;
private int businessSeats;


private int gebruikteEconomySeats = 0;
private int gebruikteBusinessSeats = 0;

    public Vlucht(String vluchtCode, String bestemming, int economySeats, int businessSeats) {
        this.vluchtCode = vluchtCode;
        this.bestemming = bestemming;
        this.passagiers = new ArrayList<>();
        this.personeel = new ArrayList<>();
        this.tickets = new ArrayList<>();
        this.economySeats = economySeats;
        this.businessSeats = businessSeats;

    }
//    Methode voor Tickets (anti-dubble)

    //bestaat die
    public void voegTicketToe(Tickets ticket){
        if (tickets.contains(ticket)){
            System.out.println("Dit ticket bestaat al.");
            return;
        }
    //is die beschikbaar

        if (ticket.getStoelKlasse() == Tickets.StoelKlasse.ECONOMY) {
            reserveerStoel(1);
        } else if (ticket.getStoelKlasse() == Tickets.StoelKlasse.BUSINESS) {
            reserveerStoel(2);
        }
        tickets.add(ticket);
        System.out.println("Ticket toegevoegd: " + ticket);
    }
// overzicht tickets (gekopeld aan bestaande vlucht)
    public void toonTickets() {
        if (tickets.isEmpty()) {
            System.out.println("Geen tickets beschikbaar voor deze vlucht.");
        } else {
            for (Tickets ticket : tickets) {
                System.out.println(ticket);
            }
        }
    }
    //ik controleer als seats beschikbaar zijn
    public boolean isEconomyBeschikbaar(){
        return gebruikteEconomySeats < economySeats;
    }
    public boolean isBusinessBeschikbaar(){
        return gebruikteBusinessSeats < businessSeats;
    }
    //stoel reserveren:
public void reserveerStoel(int keuze){
       try{ switch (keuze){
            case 1 :
                if (!isEconomyBeschikbaar()){
                    throw new IllegalArgumentException("Geen beschikbare economy stoelen.");
                }
                gebruikteEconomySeats++;
                System.out.println("Economy stoel succesvol gereserveerd!");
                break;

            case 2 :
                if (!isBusinessBeschikbaar()){
                    throw new IllegalArgumentException("Geen beschikbare business stoelen");
                }
                gebruikteBusinessSeats++;
                System.out.println("Business stoel succesvol gereserveerd!");
                break;

            default:
                throw new IllegalArgumentException("Ongeldige keuze. Kies 1 (economy) of 2 (business).");
        }
} catch (IllegalArgumentException e) {
           System.out.println("Fout: "+ e.getMessage());
       }
}


        //stoelbeschikbaarheid (volledig):

 public void toonStoelBeschikbaarheid(){

            int beschikbareEconomy = economySeats - gebruikteEconomySeats;
            int beschikbareBusiness = businessSeats - gebruikteBusinessSeats ;

            System.out.println("Beschikbare stoelen: ");
            System.out.println("Economy: "+ beschikbareEconomy);
            System.out.println("Business: "+ beschikbareBusiness);

    }


    public boolean magVertrekken(){
        int aantalPiloten = 0;
        int aantalBagagisten = 0;
        int aantalStewards = 0;
//ik tel aantal personeel (per klasse)
        for (Personeel p : personeel){
            if (p instanceof Piloot){
                aantalPiloten++;
            } else if (p instanceof Bagagist) {
                aantalBagagisten++;
            } else if (p instanceof Steward) {
                aantalStewards++;
            }
        }
if(aantalPiloten < 1){
    System.out.println("Niet genoeg piloten. Er zijn er momenteel enkel " + aantalPiloten+" beschikbaar, minimum 2 nodig.");
    return false;
}
if (aantalBagagisten < 1){
    System.out.println("Niet genoeg bagagisten. Er zijn er momenteel enkel " + aantalBagagisten+" beschikbaar, minimum 4 nodig.");
    return false;
}
        if (aantalStewards < 1){
            System.out.println("Niet genoeg stewards. Er zijn er momenteel enkel " + aantalStewards+" beschikbaar, minimum 3 nodig.");
            return false;
        }
        System.out.println("Alle personeel aanwezig, de vlucht mag vertrekken!");
        return true;
    }
//methode om personeel en passagiers toe te voegen (+controle geen dubbel)
public void voegPassagierToe(Passagier passagier){
        if (!passagiers.contains(passagier)){
            passagiers.add(passagier);
            System.out.println("Passagier toegevoegd: " + passagier.getNaam());
        } else {
            System.out.println("Passagier "+ passagier.getNaam() + " is al toegevoegd.");
        }
}
public void voegPersoneelToe(Personeel p){
        if (!personeel.contains(p)) {
            personeel.add(p);
            System.out.println("Personeel toegevoegd: " + p.getNaam());
        } else {
            System.out.println("Personeelslid " + p.getNaam() + "is al toegevoegd.");
        }
}

    public List<Tickets> getTickets() {
        return tickets;
    }

    public void setTickets(List<Tickets> tickets) {
        this.tickets = tickets;
    }

    public String getVluchtCode() {
        return vluchtCode;
    }

    public void setVluchtCode(String vluchtCode) {
        this.vluchtCode = vluchtCode;
    }

    public String getBestemming() {
        return bestemming;
    }

    public void setBestemming(String bestemming) {
        this.bestemming = bestemming;
    }


    public List<Passagier> getPassagiers() {
        return passagiers;
    }

    public void setPassagiers(List<Passagier> passagiers) {
        this.passagiers = passagiers;
    }

    public List<Personeel> getPersoneel() {
        return personeel;
    }

    public void setPersoneel(List<Personeel> personeel) {
        this.personeel = personeel;
    }

    public int getEconomySeats() {
        return economySeats;
    }

    public void setEconomySeats(int economySeats) {
        this.economySeats = economySeats;
    }

    public int getBusinessSeats() {
        return businessSeats;
    }

    public void setBusinessSeats(int businessSeats) {
        this.businessSeats = businessSeats;
    }

    @Override
    public String toString() {
        return "Vlucht{" +
                "vluchtCode='" + vluchtCode + '\'' +
                ", bestemming='" + bestemming + '\'' +
                ", passagiers=" + passagiers +
                ", personeel=" + personeel +
                ", economySeats=" + economySeats +
                ", businessSeats=" + businessSeats +
                ", gebruikteEconomySeats=" + gebruikteEconomySeats +
                ", gebruikteBusinessSeats=" + gebruikteBusinessSeats +
                '}';
    }
}



