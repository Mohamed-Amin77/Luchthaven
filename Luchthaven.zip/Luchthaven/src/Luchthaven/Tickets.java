package Luchthaven;

import Luchthaven.People.Passagier;

public class Tickets {
    public enum StoelKlasse { ECONOMY, BUSINESS }

    private String ticketCode;
    private Passagier passagier;
    private Vlucht vlucht;
    private StoelKlasse stoelKlasse;


    public Tickets(String ticketCode, Passagier passagier, Vlucht vlucht, StoelKlasse stoelKlasse) {
        this.ticketCode = ticketCode;
        this.passagier = passagier;
        this.vlucht = vlucht;
        this.stoelKlasse = stoelKlasse;
    }

    public String getTicketCode() {
        return ticketCode;
    }

    public void setTicketCode(String ticketCode) {
        this.ticketCode = ticketCode;
    }

    public Passagier getPassagier() {
        return passagier;
    }

    public void setPassagier(Passagier passagier) {
        this.passagier = passagier;
    }

    public Vlucht getVlucht() {
        return vlucht;
    }

    public void setVlucht(Vlucht vlucht) {
        this.vlucht = vlucht;
    }

    public StoelKlasse getStoelKlasse() {
        return stoelKlasse;
    }

    public void setStoelKlasse(StoelKlasse stoelKlasse) {
        this.stoelKlasse = stoelKlasse;
    }

    @Override
    public String toString() {
        return "Tickets{" +
                "ticketCode=" + ticketCode +
                ", passagier=" + passagier +
                ", vlucht=" + vlucht +
                ", stoelKlasse=" + stoelKlasse +
                '}';
    }
}
