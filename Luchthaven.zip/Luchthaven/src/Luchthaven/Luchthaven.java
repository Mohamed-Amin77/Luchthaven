package Luchthaven;

import Luchthaven.People.Passagier;
import Luchthaven.People.Personeel.Bagagist;
import Luchthaven.People.Personeel.Personeel;
import Luchthaven.People.Personeel.Piloot;
import Luchthaven.People.Personeel.Steward;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Luchthaven {
    static Scanner scanny = new Scanner(System.in);

    public static void main(String[] args) {
        List<Vlucht> vluchten = new ArrayList<>();

        Vlucht v1 = new Vlucht("FL123", "Brussel", 50, 10);
        System.out.println(v1);
        Passagier p1 = new Passagier("Friedbert Bertfried", 25, "Copelbupelstraat", Passagier.Maaltijd.VEGETARISCH, 15);
        System.out.println(p1);
        Passagier p2 = new Passagier("Zakiya Hbiba", 24, "Mouksstraat", Passagier.Maaltijd.STANDAARD, 24);
        System.out.println(p2);

        Passagier p3 = new Passagier("Chaks du Chuks", 24, "HUJO", Passagier.Maaltijd.GEEN_MAALTIJD, 22);
        System.out.println(p3);
        Piloot pl1 = new Piloot("Koen", 40,"Gent", 4, "Piloot", 5);
        Bagagist bg1 = new Bagagist("Karel", 28, "Brussel", 1100, "Bagagist");
        Steward s1 = new Steward("Karel", 28, "Brussel", 1100, "Bagagist", "FR,ENG,AR");

        Tickets t1 = new Tickets("T123",p1, v1, Tickets.StoelKlasse.ECONOMY);
        System.out.println(t1);

        v1.voegPersoneelToe(pl1);
        v1.voegPersoneelToe(bg1);
        v1.voegPersoneelToe(s1);
        v1.voegPassagierToe(p2);


        System.out.println("Passagiers in vlucht: "+ v1.getPassagiers().size());
        System.out.println("Personeel in vlucht: "+ v1.getPersoneel().size());
        System.out.println("Volledige info: "+ v1);


        char keuze;
        do{
            System.out.println("Luchthaven Menu");
            System.out.println("1) Nieuwe vluchten aanmaken");
            System.out.println("2)Passagier toevoegen aan vlucht");
            System.out.println("3) Personeel toevoegen aan een vlucht");
            System.out.println("4) Nieuwe ticket aanmaken");
            System.out.println("5) Toon informatie van een vlucht");
            System.out.println("6) Onboarding");
            System.out.println("7) Check of een vlucht mag vertrekken");
            System.out.println("8) Vluchtinfo printen");
            System.out.println("9) Stoppen");
            System.out.print("Maak een keuze: ");
            keuze = scanny.next().charAt(0);

            switch(keuze) {
                case '1': nieuweVluchtAanmaken(scanny, vluchten);
                    break;
                case '2': passagierToevoegen(scanny, vluchten);
                    break;
                case '3': personeelToevoegen(scanny, vluchten);
                    break;
                case '4': ticketAanmaken(scanny, vluchten);
                    break;
                case '5': toonVluchtInfo(scanny, vluchten);
                    break;
                case '6': boarding(scanny, vluchten);
                    break;
                case '7': checkMagVertrekken(scanny, vluchten);
                    break;
                case '8': exportVluchtInfo(vluchten);
                    break;
                case '9':
                    System.out.println("Programma gestopt.");
                    break;

            }

        }while (keuze != '9');



        }
    private static void nieuweVluchtAanmaken(Scanner scanny, List<Vlucht> vluchten) {
        System.out.println("Vluchtcode: ");
        String code = scanny.next();

        // Controleer of de vluchtcode al bestaat
        for (int i = 0; i < vluchten.size(); i++) {
            if (vluchten.get(i).getVluchtCode().equalsIgnoreCase(code)) {
                System.out.println("Fout: Vluchtcode bestaat al!");
                return;
            }
        }

        System.out.println("Bestemming: ");
        String bestemming = scanny.next();

        System.out.print("Aantal economy stoelen: ");
        int economySeats = scanny.nextInt();


        System.out.print("Aantal business stoelen: ");
        int businessSeats = scanny.nextInt();
        scanny.nextLine(); // Scanner opschonen

        // Controleer op negatieve aantallen
        if (economySeats < 0 || businessSeats < 0) {
            System.out.println("Stoelaantallen moeten positief zijn!");
            return;
        }

        // Maak de nieuwe vlucht
        Vlucht nieuweVlucht = new Vlucht(code, bestemming, economySeats, businessSeats);

        // Voeg de vlucht toe aan de lijst
        vluchten.add(nieuweVlucht);
        System.out.println("Nieuwe vlucht succesvol aangemaakt: " + nieuweVlucht);
    }

    private static void passagierToevoegen(Scanner scanny, List<Vlucht> vluchten) {
        // Toon beschikbare vluchten
        if (vluchten.isEmpty()) {
            System.out.println("Er zijn geen vluchten beschikbaar.");
            return;
        }

        System.out.println("Beschikbare vluchten:");
        for (int i = 0; i < vluchten.size(); i++) {
            System.out.println((i + 1) + ") " + vluchten.get(i).getVluchtCode() + " - " + vluchten.get(i).getBestemming());
        }

        // Vraag om een vlucht te kiezen
        int keuze;
        do{
            System.out.print("Kies een vlucht (nummer): ");
            keuze = scanny.nextInt();

            if(keuze < 1 || keuze > vluchten.size()){
                System.out.println("Ongeldige keuze.");
            }
        }while(keuze < 1 || keuze > vluchten.size());

        Vlucht geselecteerdeVlucht = vluchten.get(keuze - 1);

        // Vraag passagiersgegevens
        System.out.print("Naam van de passagier: ");
        String naam = scanny.next();

        System.out.print("Leeftijd van de passagier: ");
        int leeftijd = scanny.nextInt();
        //scanny.next(); // Opschonen

        System.out.print("Adres van de passagier: ");
        String adres = scanny.next();

        System.out.println("Kies maaltijdoptie: ");
        System.out.println("1) Geen maaltijd");
        System.out.println("2) Standaard maaltijd");
        System.out.println("3) Vegetarische maaltijd");
        System.out.print("Maaltijdoptie: ");
        int maaltijdKeuze = scanny.nextInt();

        Passagier.Maaltijd gekozenMaaltijd = switch (maaltijdKeuze) {
            case 1 -> Passagier.Maaltijd.GEEN_MAALTIJD;
            case 2 -> Passagier.Maaltijd.STANDAARD;
            case 3 -> Passagier.Maaltijd.VEGETARISCH;
            default -> {
                System.out.println("Ongeldige keuze, standaard maaltijd geselecteerd.");
                yield Passagier.Maaltijd.STANDAARD;
            }
        };

        System.out.print("Bagagegewicht (kg): ");
        double bagagegewicht;
        try {
            bagagegewicht = scanny.nextDouble();
        //    scanny.nextLine(); // Opschonen
        } catch (IllegalArgumentException e) {
            System.out.println("Fout: " + e.getMessage());
            return;
        }

        // Maak de passagier en voeg toe aan de vlucht
        Passagier nieuwePassagier = new Passagier(naam, leeftijd, adres, gekozenMaaltijd, bagagegewicht);

        try {
            geselecteerdeVlucht.voegPassagierToe(nieuwePassagier);
        } catch (IllegalArgumentException e) {
            System.out.println("Fout bij toevoegen: " + e.getMessage());
        }
    }


    private static void personeelToevoegen(Scanner scanny, List<Vlucht> vluchten) {
        // Toon beschikbare vluchten
        if (vluchten.isEmpty()) {
            System.out.println("Er zijn geen vluchten beschikbaar.");
            return;
        }

        System.out.println("Beschikbare vluchten:");
        for (int i = 0; i < vluchten.size(); i++) {
            System.out.println((i + 1) + ") " + vluchten.get(i).getVluchtCode() + " - " + vluchten.get(i).getBestemming());
        }

        // Vraag om een vlucht te kiezen
        System.out.print("Kies een vlucht (nummer): ");
        int vluchtKeuze = scanny.nextInt() - 1;
        scanny.nextLine(); // Opschonen

        if (vluchtKeuze < 0 || vluchtKeuze >= vluchten.size()) {
            System.out.println("Ongeldige keuze.");
            return;
        }

        Vlucht geselecteerdeVlucht = vluchten.get(vluchtKeuze);

        // Personeelstype selecteren
        System.out.println("Welk type personeel wilt u toevoegen?");
        System.out.println("1) Piloot");
        System.out.println("2) Bagagist");
        System.out.println("3) Steward");
        char keuze = scanny.next().charAt(0);
        scanny.nextLine(); // Opschonen

        // Algemene personeelsinformatie opvragen
        System.out.print("Naam: ");
        String naam = scanny.nextLine();

        System.out.print("Leeftijd: ");
        int leeftijd = scanny.nextInt();
        scanny.nextLine(); // Opschonen

        System.out.print("Adres: ");
        String adres = scanny.nextLine();

        // Specifieke informatie per personeelstype
        switch (keuze) {
            case '1':
                System.out.print("Aantal vlieguren: ");
                int vlieguren = scanny.nextInt();
                scanny.nextLine(); // Opschonen

                Piloot piloot = new Piloot(naam, leeftijd, adres, 0, "Piloot", vlieguren);
                geselecteerdeVlucht.voegPersoneelToe(piloot);
                break;

            case '2':
                System.out.print("Personeelsnummer: ");
                int personeelsnummer = scanny.nextInt();
                scanny.nextLine(); // Opschonen

                Bagagist bagagist = new Bagagist(naam, leeftijd, adres, personeelsnummer, "Bagagist");
                geselecteerdeVlucht.voegPersoneelToe(bagagist);
                break;

            case '3':
                System.out.print("Gesproken talen (gescheiden door komma): ");
                String talen = scanny.nextLine();

                Steward steward = new Steward(naam, leeftijd, adres, 0, "Steward", talen);
                geselecteerdeVlucht.voegPersoneelToe(steward);
                break;

            default:
                System.out.println("Ongeldige keuze. Terug naar het menu.");
                break;
        }

    }

    private static void toonVluchtInfo(Scanner scanny, List<Vlucht> vluchten) {
        if (vluchten.isEmpty()) {
            System.out.println("Er zijn geen vluchten beschikbaar.");
            return;
        }

        System.out.println("Beschikbare vluchten:");
        for (int i = 0; i < vluchten.size(); i++) {
            System.out.println((i + 1) + ") " + vluchten.get(i).getVluchtCode() + " - " + vluchten.get(i).getBestemming());
        }

        int keuze;
        do{
            System.out.print("Kies een vlucht (nummer): ");
            keuze = scanny.nextInt();

            if(keuze < 1 || keuze > vluchten.size()){
                System.out.println("Ongeldige keuze.");
            }
        }while(keuze < 1 || keuze > vluchten.size());

        Vlucht geselecteerdeVlucht = vluchten.get(keuze - 1);

        System.out.println("\n--- Informatie over de vlucht ---");
        System.out.println("Vluchtcode: " + geselecteerdeVlucht.getVluchtCode());
        System.out.println("Bestemming: " + geselecteerdeVlucht.getBestemming());
        System.out.println("Passagiers: " + geselecteerdeVlucht.getPassagiers().size());
        System.out.println("Personeel: " + geselecteerdeVlucht.getPersoneel().size());
        System.out.println("\nPassagierslijst:");
        List<Passagier> passagiers = geselecteerdeVlucht.getPassagiers();
        for (int i = 0; i < passagiers.size(); i++) {
            System.out.println(" - " + passagiers.get(i));
        }

        System.out.println("\nPersoneelslijst:");
        List<Personeel> personeel = geselecteerdeVlucht.getPersoneel();
        for (int i = 0; i < personeel.size(); i++) {
            System.out.println(" - " + personeel.get(i));
        }
        System.out.println("\nTickets:");
        geselecteerdeVlucht.toonTickets();
        System.out.println("---------------------------------");
    }


    private static void checkMagVertrekken(Scanner scanny, List<Vlucht> vluchten) {
        if (vluchten.isEmpty()) {
            System.out.println("Er zijn geen vluchten beschikbaar.");
            return;
        }

        System.out.println("Beschikbare vluchten:");
        for (int i = 0; i < vluchten.size(); i++) {
            System.out.println((i + 1) + ") " + vluchten.get(i).getVluchtCode() + " - " + vluchten.get(i).getBestemming());
        }

        int keuze;
        do{
            System.out.print("Kies een vlucht (nummer): ");
            keuze = scanny.nextInt();

            if(keuze < 1 || keuze > vluchten.size()){
                System.out.println("Ongeldige keuze.");
            }
        }while(keuze < 1 || keuze > vluchten.size());

        Vlucht geselecteerdeVlucht = vluchten.get(keuze - 1);

        System.out.println("Controleer of de vlucht mag vertrekken...");
        if (geselecteerdeVlucht.magVertrekken()) {
            System.out.println("De vlucht " + geselecteerdeVlucht.getVluchtCode() + " mag vertrekken!");
        } else {
            System.out.println("De vlucht " + geselecteerdeVlucht.getVluchtCode() + " mag niet vertrekken.");
        }
    }

    private static void ticketAanmaken(Scanner scanny, List<Vlucht> vluchten) {
        // Controleer of er vluchten beschikbaar zijn
        if (vluchten.isEmpty()) {
            System.out.println("Er zijn geen vluchten beschikbaar.");
            return;
        }

        // Toon beschikbare vluchten
        System.out.println("Beschikbare vluchten:");
        for (int i = 0; i < vluchten.size(); i++) {
            System.out.println((i + 1) + ") " + vluchten.get(i).getVluchtCode() + " - " + vluchten.get(i).getBestemming());
        }

        // Kies een vlucht
        System.out.print("Kies een vlucht (nummer): ");
        int keuze;
        do {
            keuze = scanny.nextInt();
            if (keuze < 1 || keuze > vluchten.size()) {
                System.out.println("Ongeldige keuze. Probeer opnieuw.");
            }
        } while (keuze < 1 || keuze > vluchten.size());

        Vlucht geselecteerdeVlucht = vluchten.get(keuze - 1);

        // Controleer of er passagiers zijn toegevoegd aan de vlucht
        if (geselecteerdeVlucht.getPassagiers().isEmpty()) {
            System.out.println("Er zijn geen passagiers geregistreerd voor deze vlucht.");
            return;
        }

        // Toon beschikbare passagiers
        System.out.println("Beschikbare passagiers:");
        List<Passagier> passagiers = geselecteerdeVlucht.getPassagiers();
        for (int i = 0; i < passagiers.size(); i++) {
            System.out.println((i + 1) + ") " + passagiers.get(i).getNaam());
        }

        // Kies een passagier
        System.out.print("Kies een passagier (nummer): ");
        int passagierKeuze;
        do {
            passagierKeuze = scanny.nextInt();
            if (passagierKeuze < 1 || passagierKeuze > passagiers.size()) {
                System.out.println("Ongeldige keuze. Probeer opnieuw.");
            }
        } while (passagierKeuze < 1 || passagierKeuze > passagiers.size());

        Passagier geselecteerdePassagier = passagiers.get(passagierKeuze - 1);

        // Kies stoelklasse
        System.out.println("Kies stoelklasse:");
        System.out.println("1) Economy");
        System.out.println("2) Business");
        int stoelKeuze;
        Tickets.StoelKlasse stoelKlasse;
        do {
            stoelKeuze = scanny.nextInt();
            if (stoelKeuze == 1) {
                stoelKlasse = Tickets.StoelKlasse.ECONOMY;
            } else if (stoelKeuze == 2) {
                stoelKlasse = Tickets.StoelKlasse.BUSINESS;
            } else {
                System.out.println("Ongeldige keuze. Probeer opnieuw.");
                stoelKlasse = null;
            }
        } while (stoelKlasse == null);

        // Genereer een unieke ticketcode (bijv. door een combinatie van passagier en vluchtcode)
        int random = (int) Math.random() * 1_000_000;
        String ticketCode = "T" + random;
        // Maak het ticket aan
        Tickets nieuwTicket = new Tickets(ticketCode, geselecteerdePassagier, geselecteerdeVlucht, stoelKlasse);

        // Voeg het ticket toe aan de vlucht
        try {
            geselecteerdeVlucht.voegTicketToe(nieuwTicket);
            System.out.println("Ticket succesvol aangemaakt en toegevoegd aan de vlucht:");
            System.out.println(nieuwTicket);
        } catch (IllegalArgumentException e) {
            System.out.println("Fout bij het toevoegen van het ticket: " + e.getMessage());
        }
    }

    private static void boarding(Scanner scanny, List<Vlucht> vluchten) {
        // Controleer of er vluchten beschikbaar zijn
        if (vluchten.isEmpty()) {
            System.out.println("Er zijn geen vluchten beschikbaar.");
            return;
        }

        // Toon beschikbare vluchten
        System.out.println("Beschikbare vluchten:");
        for (int i = 0; i < vluchten.size(); i++) {
            System.out.println((i + 1) + ") " + vluchten.get(i).getVluchtCode() + " - " + vluchten.get(i).getBestemming());
        }

        // Kies een vlucht
        System.out.print("Kies een vlucht (nummer): ");
        int keuze;
        do {
            keuze = scanny.nextInt();
            if (keuze < 1 || keuze > vluchten.size()) {
                System.out.println("Ongeldige keuze. Probeer opnieuw.");
            }
        } while (keuze < 1 || keuze > vluchten.size());

        Vlucht geselecteerdeVlucht = vluchten.get(keuze - 1);

        System.out.println("\n--- Boarding gestart voor vlucht: " + geselecteerdeVlucht.getVluchtCode() + " ---");

        // Controleer of er tickets beschikbaar zijn
        if (geselecteerdeVlucht.getTickets().isEmpty()) {
            System.out.println("Geen tickets beschikbaar voor deze vlucht. Boarding niet mogelijk.");
            return;
        }

        // Process each ticket met een normale for-lus
        List<Tickets> tickets = geselecteerdeVlucht.getTickets();
        for (int i = 0; i < tickets.size(); i++) {
            Tickets ticket = tickets.get(i);
            Passagier passagier = ticket.getPassagier();

            // Controleer stoelbeschikbaarheid
            try {
                if (ticket.getStoelKlasse() == Tickets.StoelKlasse.ECONOMY) {
                    geselecteerdeVlucht.reserveerStoel(1);
                } else if (ticket.getStoelKlasse() == Tickets.StoelKlasse.BUSINESS) {
                    geselecteerdeVlucht.reserveerStoel(2);
                }

                // Voeg passagier toe aan de vlucht
                geselecteerdeVlucht.voegPassagierToe(passagier);
                System.out.println("Passagier " + passagier.getNaam() + " succesvol geboard!");

            } catch (IllegalArgumentException e) {
                System.out.println("Fout bij boarding van passagier " + passagier.getNaam() + ": " + e.getMessage());
            }
        }

        System.out.println("\n--- Boarding voltooid voor vlucht: " + geselecteerdeVlucht.getVluchtCode() + " ---");
    }

    public static void exportVluchtInfo(List<Vlucht> vluchten) {
        // Controleer of er vluchten beschikbaar zijn
        if (vluchten == null || vluchten.isEmpty()) {
            System.out.println("Geen vluchten beschikbaar.");
            return;
        }

        // Toon beschikbare vluchten
        System.out.println("Beschikbare vluchten:");
        for (int i = 0; i < vluchten.size(); i++) {
            System.out.println((i + 1) + ") " + vluchten.get(i).getVluchtCode() + " - " + vluchten.get(i).getBestemming());
        }

        // Vraag de gebruiker om een vlucht te kiezen
        System.out.print("Kies een vlucht (nummer): ");
        int keuze;
        do {
            keuze = scanny.nextInt();
            if (keuze < 1 || keuze > vluchten.size()) {
                System.out.println("Ongeldige keuze. Probeer opnieuw.");
            }
        } while (keuze < 1 || keuze > vluchten.size());

        Vlucht geselecteerdeVlucht = vluchten.get(keuze - 1);

        // Bestand naam gebaseerd op de vluchtcode
        String bestandNaam = "VluchtInfo_" + geselecteerdeVlucht.getVluchtCode() + ".txt";

        try (FileWriter writer = new FileWriter(bestandNaam)) {
            writer.write("=============== Vluchtinformatie ===============\n");
            writer.write("Vluchtcode: " + geselecteerdeVlucht.getVluchtCode() + "\n");
            writer.write("Bestemming: " + geselecteerdeVlucht.getBestemming() + "\n");
            writer.write("==============================================\n\n");

            // Passagiersinformatie
            writer.write("--- Passagiersinformatie ---\n");
            List<Passagier> passagiers = geselecteerdeVlucht.getPassagiers();
            writer.write("Aantal passagiers: " + passagiers.size() + "\n");
            for (int i = 0; i < passagiers.size(); i++) {
                writer.write((i + 1) + ") " + passagiers.get(i) + "\n");
            }

            writer.write("\n");

            // Personeelsinformatie
            writer.write("--- Personeelsinformatie ---\n");
            List<Personeel> personeel = geselecteerdeVlucht.getPersoneel();
            writer.write("Aantal personeelsleden: " + personeel.size() + "\n");
            for (int i = 0; i < personeel.size(); i++) {
                writer.write((i + 1) + ") " + personeel.get(i) + "\n");
            }

            writer.write("\n");

            // Ticketinformatie
            writer.write("--- Ticketinformatie ---\n");
            List<Tickets> tickets = geselecteerdeVlucht.getTickets();
            writer.write("Aantal tickets: " + tickets.size() + "\n");
            for (int i = 0; i < tickets.size(); i++) {
                writer.write((i + 1) + ") " + tickets.get(i) + "\n");
            }

            writer.write("\n==============================================\n");

            System.out.println("Vluchtinformatie succesvol geëxporteerd naar: " + bestandNaam);
        } catch (IOException e) {
            System.out.println("Fout bij het exporteren van vluchtinformatie: " + e.getMessage());
        }
    }


}


