package Luchthaven.People.Personeel;

public class Piloot extends Personeel {
private int vlieguren;

    public Piloot(String naam, int leeftijd, String adres, int personneelsNummer, String functie, int vlieguren) {
        super(naam, leeftijd, adres, personneelsNummer);
        this.vlieguren = vlieguren;
    }

    public int getVlieguren() {
        return vlieguren;
    }

    public void setVlieguren(int vlieguren) {
        if (vlieguren <0){
            throw new  IllegalArgumentException("Vlieguren mogen niet negatief zijn.");
        }
        this.vlieguren = vlieguren;
    }

    @Override
    public String toString() {
        return super.toString() + ", Piloot{" +
                ", vlieguren=" + vlieguren +
                '}';
    }
}
