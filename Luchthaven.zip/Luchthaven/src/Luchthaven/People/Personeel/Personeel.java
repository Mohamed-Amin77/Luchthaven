package Luchthaven.People.Personeel;

import Luchthaven.People.Persoon;

public class Personeel extends Persoon {
    private int personeelsNummer;

    public Personeel(String naam, int leeftijd, String adres, int personeelsNummer) {
        super(naam, leeftijd, adres);
        this.personeelsNummer = personeelsNummer;
    }

    public int getPersoneelsNummer() {
        return personeelsNummer;
    }

    public void setPersoneelsNummer(int personeelsNummer) {
        this.personeelsNummer = personeelsNummer;
    }

    @Override
    public String toString() {
        return super.toString() + ", Personeel{" +
                "personeelsNummer=" + personeelsNummer+
                '}';
    }
}
