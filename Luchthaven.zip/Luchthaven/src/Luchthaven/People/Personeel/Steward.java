package Luchthaven.People.Personeel;

public class Steward extends Personeel {


    public Steward(String naam, int leeftijd, String adres, int personneelsNummer, String functie, String gesprokenTalen) {
        super(naam, leeftijd, adres, personneelsNummer);
    }


    @Override
    public String toString() {
        return super.toString() + ", Steward{}";
    }
}
