package Luchthaven.People.Personeel;

public class Bagagist extends Personeel {
    public Bagagist(String naam, int leeftijd, String adres, int personneelsNummer, String functie) {
        super(naam, leeftijd, adres, personneelsNummer);
    }

    @Override
    public String toString() {
        return super.toString() + " Bagagist{}";
    }
}
