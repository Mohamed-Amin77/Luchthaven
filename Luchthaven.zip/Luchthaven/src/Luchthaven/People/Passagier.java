package Luchthaven.People;

import Luchthaven.People.Persoon;

public class Passagier extends Persoon {

    public enum Maaltijd{ GEEN_MAALTIJD, STANDAARD, VEGETARISCH;
    }
    private Maaltijd maaltijd;
    private double bagagegewicht;

    public Passagier(String naam, int leeftijd, String adres, Maaltijd maaltijd, double bagagegewicht) {
        super(naam, leeftijd, adres);
        this.maaltijd =  maaltijd;
        setBagagegewicht(bagagegewicht);

    }

    public Maaltijd getMaaltijd() {
        return maaltijd;
    }

    public void setMaaltijd(Maaltijd maaltijd) {
        this.maaltijd = maaltijd;
    }

    public double getBagagegewicht() {
        return bagagegewicht;
    }



    public void setBagagegewicht(double bagagegewicht) throws IllegalArgumentException {
        if (bagagegewicht > 25){
            throw new IllegalArgumentException("Bagage mag niet meer wegen dan 25 kg");

        }else if (bagagegewicht <0){
            throw new IllegalArgumentException("Bagagegewicht mag niet negatief zijn.");
        }
        this.bagagegewicht = bagagegewicht;



    }

    @Override
    public String toString() {
        return super.toString() + ", Passagier{" +
                "maaltijd=" + maaltijd +
                ", bagagegewicht=" + bagagegewicht +
                '}';
    }
}






